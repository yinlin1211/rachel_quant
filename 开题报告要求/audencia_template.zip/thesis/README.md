# SAFTI Final Thesis LaTeX Template

## 中文说明

学生通常只需要修改三类文件：

1. 在 `config.tex` 中填写题目、姓名、学号、导师、日期和 3–5 个关键词。
2. 在 `chapter/00-abstract.tex` 至 `chapter/07-appendices.tex` 中替换示例正文。
3. 在 `references.bib` 中添加文献，并在正文使用 `\textcite{引用键}` 或
   `\parencite{引用键}`。参考文献格式会按 GB/T 7714 自动生成。

章节结构与附件四对应：

- `chapter/00-abstract.tex`：摘要，不超过 250 词；
- `chapter/01-introduction.tex`：引言；
- `chapter/02-literature-review.tex`：至少完成 10-page literature review；
- `chapter/03-empirical-context.tex`：研究对象/背景，可选；
- `chapter/04-methodology.tex`：研究方法；
- `chapter/05-results-analysis.tex`：结果与分析；
- `chapter/06-conclusion.tex`：结论；
- `chapter/07-appendices.tex`：附录，可选。

完整论文应达到附件四要求的 50-page thesis（不含附录）。如果不需要可选
章节，请在 `main.tex` 中删除对应的 `\include` 行。不要修改
`safti-thesis.cls`，除非学校发布了新的正式版式要求。

### 在线编译平台

将编译器设为 **XeLaTeX**，
将 **Main document** 设为 `main.tex`。平台通常会自动调用 **Biber**；
如引用暂时显示为问号，请选择“从头重新编译”或按
XeLaTeX → Biber → XeLaTeX → XeLaTeX 的顺序编译。

## English Quick Start

1. Edit only the values in `config.tex`.
2. Replace the sample prose in the files under `chapter/`.
3. Add BibTeX records to `references.bib`; cite them with `\textcite{key}` or
   `\parencite{key}`.
4. Select **XeLaTeX**, set the **Main document** to `main.tex`, and use
   **Biber** for the bibliography.

The top-level `main.tex` intentionally contains only the assembly order. Layout,
cover design, headers, numbering, combined lists, and GB/T 7714 references are owned
by `safti-thesis.cls`. The template includes one equation, one three-line
table, one figure, and all common citation forms as working examples.
